from django import forms

from .models import Booking

class Bookingform(forms.ModelForm):
    
    class Meta:
        model = Booking
        fields='__all__'

        labels={
                'name': "Name",
                'phone': "Phone No",
                'carfrom': "From",
                'carto': "To",                
         }
        