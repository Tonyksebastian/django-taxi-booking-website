from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib import auth
from django.contrib import messages
from django.contrib.auth.models import User
from .forms import Bookingform

def home(request):
   return render(request,'index.html')


   
def login(request):
    if request.method == 'POST':
        username = request.POST.get('uname')
        password = request.POST.get('password')
        user=auth.authenticate(username=username,password=password)
        if user is not None:
            auth.login(request,user)

        return render(request, 'index.html')

    return render(request, 'login.html')


def register(request):
    if request.method == 'POST':
        username = request.POST['name']
        email = request.POST['email']
        password = request.POST['password']
        confirmpassword = request.POST['cpassword']  

        if password == confirmpassword:
            if User.objects.filter(username=username).exists():
                messages.info(request, 'Username already exists')
                return redirect('register')  
            elif User.objects.filter(email=email).exists():
                messages.info(request, 'Email ID already exists')
                return redirect('register') 
            else:
                user_reg = User.objects.create_user(username=username, email=email, password=password)
                user_reg.save()
                return render(request,'index.html')
        else:
            messages.info(request, 'Passwords do not match')
            return redirect('register') 
    return render(request, 'register.html') 

def logout(request):
    auth.logout(request)
    return render(request,'index.html')

def book(request):
    form=Bookingform()
    if request.method=='POST':
       form=Bookingform(request.POST)
       form.save()
    
    dict_book={
        'form': form
    }    
    return render(request,'index.html',dict_book)