from django.db import models

class Booking(models.Model):
    name=models.CharField(max_length=60)
    phone=models.CharField(max_length=60)
    carfrom=models.CharField(max_length=60)
    carto=models.CharField(max_length=30)
